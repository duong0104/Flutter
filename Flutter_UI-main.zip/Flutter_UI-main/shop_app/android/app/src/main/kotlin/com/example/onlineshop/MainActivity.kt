package com.example.onlineshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
